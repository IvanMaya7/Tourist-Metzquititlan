const touristPlaceService = require("./touristPlace.service")
const historyService = require("./history.service")
const gastronomyService = require("./gastronomy.service")

module.exports ={
    touristPlaceService,
    historyService,
    gastronomyService,
}