import Gastronomy from "./pages/Gastronomy";

function App() {
  return (
    <div>
      <Gastronomy />
    </div>
  );
}

export default App;
